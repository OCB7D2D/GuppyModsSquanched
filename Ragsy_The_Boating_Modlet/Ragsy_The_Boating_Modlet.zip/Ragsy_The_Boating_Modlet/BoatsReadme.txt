Experimental work in progress version of the boating modlet.

First you will probably be thinking theres not much water in 7 Days to Die rwg at present and this is very true.

No Problem , download Tin's rwg Modlet from the 7 days to die forums or the very nice pre-made world 'Guppy's Island' by Guppycur.

Links
https://7daystodie.com/forums/showthread.php?111332-Tin-s-Modlet-Tweaks

https://7daystodie.com/forums/showthread.php?122873-World-Guppys-Island


Launch

Place the boat on a flat piece of ground as usual and as near to water as possible then add fuel to boat, the Small boat is super economical on fuel so fuel will last a very very long time.

The boat will behave a bit irratically on land and will damage player made blocks, it will probably move about a bit on its own but will work very stable on water.


Controls

Usual controls for vehicles except space bar and c control the up angle (same as a gyro) which you may need to adjust slightly as you enter water depending on the 
water entry angle, once the boat is level then off you go.  If you press s whilst going forward it will slow the boat down and eventually reverse will kick in this
replaces spacebar as the brake key.

Boat can be picked up into inventory, if you sink it at any point  although be careful if you sink it too far away from the shores as it could be a long swim back as boat can not be placed in water.

The Boat is craftable in a standard workbench with no progression needed as this boat is intended as an early game version at the cost of resources and actually 
finding a working workbench in early game would be a bonus and allow you to make the boat a lot sooner.  The recipe is simple and uses in game resources.

The boat will require 3 repair kits for maintenance so take some with you ..

Along the way hopefully we can expand this to have some bigger
boats and different types of watercraft such as amphibious vehicles, a canoe, small sail boat and perhaps even a jetski. 

There are few known issues and glitches that need work arounds but hopefully these can be worked out along the way.


Happy Boating 
Ragsy and Guppycur !!

 

